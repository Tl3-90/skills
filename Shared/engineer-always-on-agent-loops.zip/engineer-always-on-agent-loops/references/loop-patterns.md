# Loop pattern catalog

## Selection table

| Pattern | Use when | Required validator | Stop rule | Main risk |
|---|---|---|---|---|
| Bounded tool loop | The task is compact and action choices depend on observations | Goal validator | Success, block, or turn/cost cap | Endless searching |
| Plan–execute–replan | Work has multiple dependent steps and facts may change | Per-step plus final validator | All valid steps complete | Stale plan becomes authority |
| Generate–verify–repair | Output is code, data, configuration, or a document | Deterministic checker plus visual/semantic QA | Validator passes or repair cap | Narrow validator misses quality |
| Evaluator–optimizer | Quality can be scored with a stable rubric | Calibrated grader | Threshold or improvement plateau | Grader gaming |
| Scheduled monitor | A bounded check repeats over time | Freshness and change detector | One activation per schedule | Duplicate or stale alerts |
| Event-driven responder | A specific external event should trigger work | Event schema and side-effect receipt | Event committed/acknowledged | Replay duplicates writes |
| Supervisor–worker | Independent specialties can run in parallel | Structured worker evidence plus supervisor acceptance | Joined synthesis accepted | Fan-out and lost accountability |

## Pattern invariants

All patterns require:

- a stable run identity and goal version;
- explicit waiting and terminal states;
- budgets and no-progress detection;
- durable evidence references;
- tool timeouts and response limits;
- checkpoint and recovery behavior;
- cancellation and operator visibility.

## Supervisor–worker contract

The supervisor defines each subtask with scope, inputs, required sources, output schema, budget, deadline, and validation. Workers return evidence, confidence, contradictions, unknowns, and status. The supervisor, not a worker majority vote, owns final acceptance.

Cap worker count and delegation depth. Use clean contexts for specialists, and pass only the evidence needed for synthesis. Do not allow specialists to expand scope silently.

## Anti-patterns

- Infinite `while true` reasoning without a durable wait state.
- Retrying the same prompt without changing evidence or strategy.
- Treating a plan as progress rather than validating completed actions.
- Using model confidence as the only success test.
- Spawning agents without a join policy or accountable owner.
- Scheduling a new run before the prior side effect is reconciled.
