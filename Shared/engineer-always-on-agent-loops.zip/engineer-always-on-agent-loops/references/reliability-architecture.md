# Durable architecture and reliability

## Reference architecture

### Control plane

Owns run IDs, goal versions, status, schedules, event offsets, leases, approvals, budgets, checkpoints, and audit history. It must survive worker loss.

### Execution plane

Hosts bounded model turns, retrieval, browser or code sessions, and tool calls. Workers may be replaced without losing accepted work.

### State services

- **Run ledger:** authoritative state machine and optimistic version.
- **Checkpoint store:** completed actions, evidence, pending work, budget, and safe resume point.
- **Artifact store:** files and immutable source captures.
- **Short-term state:** one run or thread.
- **Long-term memory:** cross-run facts and preferences with provenance, scope, expiry, and conflict rules.
- **Side-effect ledger:** intended, attempted, confirmed, reconciled, or indeterminate external actions.

## Identifier taxonomy

Keep identifiers distinct: an external event ID deduplicates ingestion; a correlation ID groups related business activity; a run ID identifies one durable goal instance; a goal version invalidates stale work; an attempt or lease ID identifies worker ownership; an action ID plus idempotency key governs one side effect; and a trace ID connects telemetry. Parent/child run IDs preserve delegation lineage.

## Minimum state machine

`CREATED → READY → LEASED → RUNNING`

From `RUNNING`, allow `CHECKPOINTED`, `WAITING`, `APPROVAL`, `SUCCEEDED`, `BLOCKED`, or `FAILED`. Also support `CANCELLED`, `REJECTED`, and `EXPIRED`. Define legal transitions and guard them with compare-and-set versioning or an equivalent concurrency mechanism.

Success requires acceptance tests. A model message saying “done” is not a terminal validator.

## Checkpoint contents

- run and goal version;
- completed action IDs and output references;
- current plan or next safe transition;
- evidence records and freshness timestamps;
- pending dependencies and approvals;
- side-effect ledger and reconciliation status;
- remaining time, turn, cost, call, and write budgets;
- context or skill version needed to resume.

## Idempotency

Derive action keys from stable business identity, run goal version, operation, and target. Store the key before or atomically with the external write where possible. On retry, query or reconcile external state. Never assume timeout means failure.

## Ownership and recovery

Use a lease, lock, workflow token, or equivalent exclusive-execution primitive. Record owner, expiry, heartbeat, attempt, and checkpoint version. An expired lease returns work to recovery. Apply bounded exponential backoff with jitter; quarantine poison tasks.

## Tool gateway

Every tool should have typed inputs, explicit identity, least privilege, timeout, size limits, rate-limit policy, retry classification, side-effect class, approval rule, idempotency support, evidence output, and rollback/reconciliation guidance.

Treat inbound and outbound webhooks differently. Inbound handling verifies signature, schema, event ID, ordering, deduplication, and poison-event policy. Outbound handling classifies 2xx, 4xx, 5xx, 429, and ambiguous timeouts; honors retry guidance; and requires idempotency plus reconciliation. Use an inbox/outbox or equivalent atomic handoff when ledger state and event delivery must not diverge.

## Version-bound approvals

An approval record should bind approver, scope, expiry, exact action/preview hash, target, important source-state version, and policy version. Define batch and partial approval, human edits, revocation, rejection, expiry, and re-approval behavior. Before execution, re-read mutable authoritative facts; if the target or material facts changed, block or generate a new preview for approval.

## Context and memory

Rebuild context from the current goal, latest checkpoint, relevant memory, fresh sources, tool schemas, and policy. Do not load entire transcripts by default. Preserve structured state outside lossy summaries.

Memory records need provenance, scope, owner, confidence, created time, expiry, and conflict handling. Product language such as “learns” does not by itself prove model-weight training.

## Scheduling and events

Schedules require time-zone, daylight-saving, missed-run, overlap, and catch-up policies. Events require authentication, schema validation, ordering policy, deduplication, debounce/coalescing, and poison-event handling.

Safe defaults are: explicit named time zone; no overlapping run for the same business key; coalesce missed low-urgency checks into one current run; never replay a consequential action merely to “catch up”; and require a documented override for parallel catch-up.

## Data governance

Define tenant isolation, encryption, access control, retention, deletion/export, sensitive-data minimization, redaction, region, and compliance needs for transcripts, checkpoints, artifacts, memory, and traces. Do not retain raw conversation content when structured state or redacted evidence is sufficient.

## Always-on interpretation

The service remains continuously available; reasoning activates only for ready work. While waiting, persist state and release expensive workers. This reduces cost and creates a clear recovery boundary.
