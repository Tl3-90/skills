# Grok Bot public case study

Research cutoff: August 25, 2026.

## Observed public behavior

xAI public material describes:

- named Bots with roles and persistent context;
- a persistent user-scoped cloud computer with browser, files, terminal, and connected applications;
- shared files, sessions, and workspace resources among a user’s Bots;
- skills that encode reusable instructions, decisions, output, validation, and boundaries;
- routines bound to schedules or events, with testing and run history;
- background cloud work after the client closes;
- multi-Bot threads, handoffs, group collaboration, and coordinator roles;
- approval controls, Auto Review, secret handoff, and least-privilege guidance;
- restart, recover, update, snapshot, and reset behavior;
- separate public API capabilities for tool loops, web/X search, code execution, streaming, context compaction, and multi-agent work.

## Strong architecture hypothesis

The behavior is most consistent with a durable server-side control plane that creates bounded activations on messages, schedules, events, or recovery signals. A worker builds context, executes a limited model/tool loop, passes consequential actions through policy review, persists artifacts and state, and reaches success, waiting, approval, or recovery.

Likely components such as a queue, lease/heartbeat, event log, and checkpoint service are inferences, not disclosed facts. The exact use of xAI public API endpoints internally is speculative.

## Key distinctions

- “24/7” supports continuous cloud availability and background/triggered work, not an infinite model call.
- “Learns” can be explained by persisted instructions, preferences, summaries, memories, artifacts, and routines; it does not prove model-weight training.
- Bots share a user-scoped computer, so separate Bot views should not be treated as per-Bot security boundaries.
- Grok Bot, Grok Automations, Grok Build workflows, and the xAI multi-agent API are distinct surfaces unless a source explicitly connects their implementation.

## First-party sources

- https://x.ai/news/introducing-grok-bot
- https://docs.x.ai/grok-bot/overview
- https://docs.x.ai/grok-bot/bots
- https://docs.x.ai/grok-bot/chat-and-collaboration
- https://docs.x.ai/grok-bot/files-and-results
- https://docs.x.ai/grok-bot/computer-and-apps
- https://docs.x.ai/grok-bot/skills-routines-and-automations
- https://docs.x.ai/grok-bot/settings-and-notifications
- https://docs.x.ai/grok-bot/approvals-security-and-privacy
- https://docs.x.ai/grok-bot/troubleshooting
- https://docs.x.ai/developers/model-capabilities/text/multi-agent
- https://docs.x.ai/developers/tools/web-search
- https://docs.x.ai/developers/advanced-api-usage/context-compaction
- https://docs.x.ai/developers/advanced-api-usage/websocket-mode
- https://docs.x.ai/developers/rate-limits
