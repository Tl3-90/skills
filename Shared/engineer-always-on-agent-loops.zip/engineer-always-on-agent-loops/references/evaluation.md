# Evaluation and operations

## Evaluation layers

1. **Contract tests:** state transitions, schema validation, budgets, and permissions.
2. **Deterministic task validators:** factual reconciliation, tests, checksums, or structured constraints.
3. **Trajectory checks:** prohibited tools, repeated actions, evidence use, and approval behavior.
4. **Model graders:** calibrated rubric-based qualities that deterministic checks cannot capture.
5. **Human review:** high-consequence, ambiguous, novel, or policy-sensitive outcomes.
6. **Chaos and recovery tests:** forced worker loss, duplicate events, timeouts, partial commits, and stale data.

Use repeated trials for nondeterministic agents. Keep a held-out regression set and record model, prompt/skill, tool, retrieval, and policy versions.

## Production metrics

- validated success, blocked, failed, expired, rejected, and cancelled rates;
- p50/p95 time to first action and total completion time;
- cost and model turns per validated success;
- retry, recovery, lease-expiry, and dead-letter rates;
- duplicate-prevention and indeterminate-side-effect counts;
- approval request, approval latency, rejection, and expiry rates;
- source freshness and evidence completeness;
- subagent fan-out, partial-failure, and join latency;
- human correction and rollback rates.

## Release gates

Do not release until:

- success and failure states are independently testable;
- forced restart preserves progress;
- duplicate event tests produce one external effect;
- ambiguous timeout tests reconcile safely;
- budget exhaustion stops the run;
- unauthorized actions are denied;
- approvals pause and resume correctly;
- stale or missing evidence reaches a declared state;
- operator pause, resume, cancel, inspect, and retry work;
- regression trials meet the declared reliability threshold.

Declare numeric thresholds, sample size, and observation window. Sparse descriptions can prove a blocker but cannot prove readiness; request code or configuration, state schemas, representative traces, retry/approval policies, and failure-test results before issuing a positive readiness verdict.

## Audit severity

- **Critical:** can cause uncontrolled external effects, systemic security/privacy exposure, or unrecoverable loss of accepted work.
- **High:** materially undermines correctness, durability, governance, or safe recovery.
- **Medium:** degrades operability, efficiency, or evidence quality under realistic conditions.
- **Low:** localized hardening or documentation gap with limited immediate consequence.

## Failure report format

For each defect report: evidence, invariant violated, consequence, reproduction, root cause, remediation, verification test, and residual risk.
