# Public-evidence reverse engineering

## Boundaries

Use public, authorized sources only. Do not bypass authentication, scrape against explicit access restrictions, probe private infrastructure, infer or expose secrets, or imply access to undisclosed implementation details.

## Evidence hierarchy

Prefer, in order:

1. first-party product documentation and release notes;
2. first-party API references, security/privacy pages, and help centers;
3. public code repositories owned by the vendor;
4. named technical talks or papers from responsible engineers;
5. credible independent analysis;
6. community reports, used only as leads unless corroborated.

Record title, publisher, publication/update date, access date, URL, exact supported behavior, and limitations.

## Claim labels

- **Observed:** directly stated or reproducibly visible in public material.
- **Strong inference:** several observed behaviors require or strongly favor the component.
- **Plausible inference:** a common compatible design, but alternatives remain equally viable.
- **Speculative:** weakly supported hypothesis included only to frame unknowns.

Every inferred component must include its basis, at least one alternative architecture, and evidence that would falsify the claim.

## Research workflow

1. Define the product surfaces and cutoff date.
2. Search first-party domains and map relevant URLs.
3. Scrape exact pages; preserve citations and dates.
4. Build a claim-level evidence inventory.
5. Separate behavior from mechanism.
6. Model candidate components: ingress, context, orchestration, tools, retrieval, memory, streaming, policy, persistence, observability, quotas, recovery, and scheduling.
7. Compare candidate architectures and uncertainty.
8. Publish observed facts, confidence-labeled inference, contradictions, unknowns, and falsification tests.

If broad crawling is blocked or rate-limited, map the site and scrape relevant exact pages. Record the coverage limitation instead of claiming completeness.

## Common reasoning errors

- Treating a marketing phrase such as “24/7” as proof of continuous model execution.
- Treating “learns” as proof of user-specific weight updates.
- Treating a public API capability as proof that a consumer product uses that exact API internally.
- Treating separate agent screens as security isolation.
- Treating saved chat history as durable workflow state.
- Omitting negative evidence or documented unknowns.
