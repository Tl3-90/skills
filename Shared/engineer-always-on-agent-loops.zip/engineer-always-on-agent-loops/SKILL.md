---
name: engineer-always-on-agent-loops
description: Design, implement, evaluate, review, and reverse engineer durable loop-based AI agent systems. Use when building always-on, scheduled, event-driven, long-running, autonomous, tool-using, or multi-agent workflows; defining run contracts, state machines, checkpoints, retries, approvals, budgets, memory, observability, and recovery; diagnosing unreliable agent loops; or analyzing how a public agent product likely works from lawful public evidence. Trigger on requests mentioning loop engineering, agent loops, always-on agents, durable execution, background agents, scheduled agents, event-driven agents, supervisor-worker agents, agent reliability, Grok Bot architecture, or public-evidence reverse engineering of agent products.
---

# Engineer Always-On Agent Loops

Build systems that are continuously available while keeping every reasoning run finite, governed, observable, and recoverable. Treat the model as one component inside a durable control system, not as the control system itself.

## Core principle

Separate availability from computation:

- An **always-on service** remains addressable, stores durable work, and reacts to messages, schedules, events, approvals, and recovery signals.
- A **bounded run** consumes model and tool resources under explicit limits, checkpoints progress, and reaches a declared terminal or waiting state.
- A **worker** may be ephemeral. The run identity, goal version, evidence, approvals, side-effect ledger, and checkpoint must outlive it.

Never propose an infinite model call as the basis of an always-on design.

## Route the request

Choose the smallest applicable route.

| User intent | Route | Required reference |
|---|---|---|
| Explain or compare loop patterns | Pattern selection | `references/loop-patterns.md` |
| Design or implement an agent system | Architecture workflow | `references/reliability-architecture.md` |
| Review or diagnose an existing system | Reliability audit | `references/reliability-architecture.md` and `references/evaluation.md` |
| Reverse engineer a public agent product | Evidence workflow | `references/reverse-engineering.md` |
| Analyze Grok Bot specifically | Evidence workflow plus case study | `references/grok-case-study.md` |
| Define tests, metrics, or release gates | Evaluation workflow | `references/evaluation.md` |

Load only the references needed for the selected route. For a full production design, load loop patterns, reliability architecture, and evaluation.

## Architecture workflow

### 1. Establish the run contract

Before selecting a framework, define:

- goal and measurable acceptance tests;
- triggers and correlation/deduplication keys;
- authoritative inputs and freshness rules;
- side effects and approval boundaries;
- time, turn, cost, tool-call, write, subagent, and depth budgets;
- checkpoint contents and resume policy;
- success, waiting, approval, blocked, rejected, expired, failed, cancelled, and recovery states.

If the contract is stored as JSON, run:

```bash
python scripts/validate_loop_contract.py path/to/loop-contract.json
```

Treat validator errors as design blockers. Warnings require an explicit decision.

### 2. Choose the loop pattern

Select a pattern from `references/loop-patterns.md` using task shape, validator quality, trigger type, and coordination needs. Prefer the simplest pattern that can satisfy the contract.

For multi-agent work, require one accountable supervisor, bounded fan-out, structured evidence returns, a join policy, and a partial-failure policy.

### 3. Design the durable control plane

Define these components or their equivalents:

1. authenticated event ingress and normalization;
2. durable run ledger with optimistic versioning;
3. scheduler/event router;
4. queue plus lease or other exclusive ownership mechanism;
5. context builder;
6. bounded model/tool runtime;
7. tool and policy gateway;
8. checkpoint, artifact, and memory stores;
9. event history, traces, metrics, and operator status;
10. recovery controller and quarantine path.

Name the authoritative store for every state transition. If a component is intentionally omitted, explain which invariant replaces it.

### 4. Govern side effects

Classify actions by consequence. Reading public data is different from publishing, deleting, messaging, changing permissions, spending money, executing transactions, or exposing sensitive data.

For consequential actions require:

- typed parameters and least-privilege identity;
- preview of target and change;
- idempotency key and side-effect ledger;
- approval or policy decision where needed;
- timeout, retry classification, and reconciliation procedure;
- evidence and rollback information.

Do not blindly retry an action whose external commit state is indeterminate.

### 5. Make recovery explicit

Specify lease expiration, heartbeat, retryable versus non-retryable failures, exponential backoff with jitter, maximum attempts, dead-letter/review routing, checkpoint integrity, and duplicate prevention.

Test at least:

- worker loss before and after a checkpoint;
- duplicate event delivery;
- timeout after a possibly committed write;
- stale or missing input;
- rejected or expired approval;
- model or tool rate limiting;
- goal version change during execution;
- partial subagent failure.

### 6. Add observability and evaluation

Trace goal versions, context builds, model decisions, tool calls, policy decisions, state changes, checkpoints, budgets, and final validators. Define outcome metrics before launch.

Use deterministic validators for objective facts, model graders for rubric-based qualities, and human review for consequential or ambiguous results. Run repeated trials; one successful demonstration is not evidence of reliability.

### 7. Produce the implementation package

Return artifacts appropriate to the request:

- architecture and data-flow diagram;
- state-transition table;
- run-contract schema or example;
- tool/approval matrix;
- retry, checkpoint, and idempotency policy;
- memory and context policy;
- evaluation suite and operational metrics;
- failure-mode table and launch checklist;
- explicit assumptions, unknowns, and decisions.

Lead with the recommended design and the invariants it protects. Separate must-have controls from later optimizations.

## Reliability audit

When reviewing an existing system:

1. reconstruct the actual execution path from trigger to terminal state;
2. identify the authoritative run state and ownership primitive;
3. map every external side effect and replay behavior;
4. locate all unbounded loops, retries, contexts, queues, and delegations;
5. verify checkpoint completeness and resume semantics;
6. test budgets, cancellations, approvals, and version changes;
7. inspect traces and outcome validators;
8. rank findings by consequence and reproducibility.

Report evidence, impact, and a concrete remediation for each finding. Do not call a system “durable” solely because it saves chat history.

## Public-evidence reverse engineering

Use only authorized, lawful public material. Do not bypass authentication, access private code, probe for secrets, or imply non-public access.

Follow `references/reverse-engineering.md`:

1. define product surfaces and cutoff date;
2. prioritize first-party announcements, documentation, API references, and help pages;
3. capture source title, publisher, date, URL, relevant evidence, and access limits;
4. label each claim **Observed**, **Strong inference**, **Plausible inference**, or **Speculative**;
5. state alternative architectures and falsifying evidence;
6. keep adjacent products and public APIs distinct unless a source connects them;
7. compile both confirmed behavior and documented unknowns.

When the product may have changed, browse current sources. Place citations near claims and include a source index. Never turn compatible public API features into claims about an undisclosed internal stack.

## Response quality bar

A strong result must:

- define “always-on” as durable availability plus bounded activations;
- use explicit stop conditions and run budgets;
- include idempotency, checkpointing, recovery, and approval design;
- distinguish short-term state from long-term memory;
- preserve evidence provenance and freshness;
- treat multi-agent fan-out as bounded delegation, not magic parallelism;
- include measurable acceptance tests and repeated evaluations;
- clearly label facts, assumptions, inferences, and unknowns.

Reject designs that rely on continuous unbounded reasoning, model self-certification, silent retries of consequential actions, transcript-only persistence, or unrestricted shared credentials.

## References

- `references/loop-patterns.md` — pattern selection and failure modes.
- `references/reliability-architecture.md` — durable control plane, state, recovery, tools, and memory.
- `references/evaluation.md` — evaluation suite, metrics, and release gates.
- `references/reverse-engineering.md` — lawful public-evidence research method.
- `references/grok-case-study.md` — Grok Bot observations and confidence-labeled architecture hypotheses.
