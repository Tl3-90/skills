#!/usr/bin/env python3
"""Validate a JSON contract for a durable, bounded agent loop."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys


TERMINAL = {"succeeded", "blocked", "rejected", "expired", "failed", "cancelled"}
REQUIRED_BUDGETS = {"max_elapsed_minutes", "max_model_turns", "max_tool_calls"}


def validate(data: object) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(data, dict):
        return ["contract must be a JSON object"], warnings

    for key in ("name", "goal", "success", "triggers", "budgets", "terminal_states"):
        if key not in data:
            errors.append(f"missing required field: {key}")

    if not isinstance(data.get("name"), str) or not data.get("name", "").strip():
        errors.append("name must be a non-empty string")
    if not isinstance(data.get("goal"), str) or not data.get("goal", "").strip():
        errors.append("goal must be a non-empty string")
    if not isinstance(data.get("success"), list) or not data.get("success"):
        errors.append("success must be a non-empty list of measurable conditions")
    if not isinstance(data.get("triggers"), list) or not data.get("triggers"):
        errors.append("triggers must be a non-empty list")

    budgets = data.get("budgets")
    if not isinstance(budgets, dict):
        errors.append("budgets must be an object")
    else:
        missing = REQUIRED_BUDGETS - budgets.keys()
        for key in sorted(missing):
            errors.append(f"budgets missing: {key}")
        for key, value in budgets.items():
            if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0:
                errors.append(f"budget {key} must be a positive number")
        if "max_cost" not in budgets and "max_tokens" not in budgets:
            warnings.append("define max_cost or max_tokens")
        if "max_subagents" not in budgets:
            warnings.append("define max_subagents, even if zero")

    states = data.get("terminal_states")
    if not isinstance(states, list):
        errors.append("terminal_states must be a list")
    else:
        normalized = {str(s).lower() for s in states}
        missing = TERMINAL - normalized
        if missing:
            errors.append("terminal_states missing: " + ", ".join(sorted(missing)))

    side_effects = data.get("side_effects")
    if side_effects and not data.get("idempotency"):
        errors.append("side_effects require an idempotency policy")
    if side_effects and not isinstance(side_effects, dict):
        errors.append("side_effects must be an object")
    if isinstance(side_effects, dict) and side_effects.get("approval_required") and not data.get("approval"):
        warnings.append("define approval owner, expiry, rejection, and resume behavior")

    for key in ("checkpoint", "recovery", "freshness", "observability"):
        if key not in data:
            warnings.append(f"define {key} policy")
    return errors, warnings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("contract", type=Path)
    parser.add_argument("--strict", action="store_true", help="Treat warnings as errors")
    args = parser.parse_args()
    try:
        data = json.loads(args.contract.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}")
        return 2
    errors, warnings = validate(data)
    for item in errors:
        print(f"ERROR: {item}")
    for item in warnings:
        print(f"WARNING: {item}")
    if errors or (args.strict and warnings):
        return 1
    print("PASS: contract contains the required bounded-loop controls")
    return 0


if __name__ == "__main__":
    sys.exit(main())
