---
name: multi-agent-project-management
description: Coordinate multiple agents on a shared project or a large set of tasks. Use for decomposing work, defining task ownership and dependencies, choosing sequential versus parallel execution, controlling work in progress, monitoring blockers, integrating outputs, and running quality reviews across multi-agent efforts.
---

# Multi-Agent Project Management

## Purpose

Direct a group of agents to deliver one coherent outcome rather than a collection of disconnected task results. Act as the **project manager and final integrator**: retain accountability for scope, prioritization, dependencies, quality, safety, and the final delivery. Delegate execution, research, analysis, drafting, or review only when each assignment has a clear boundary and acceptance criteria.

Use a visible task system, constrained concurrency, short feedback loops, and deliberate integration. Treat task status as evidence-based: a task is not complete until its specified output passes its acceptance checks.

> Build the plan around deliverables and work packages, not a loose list of activities. PMI describes a work breakdown structure as a deliverable-oriented hierarchical decomposition of the total project scope.[1]

## Choose the Operating Model

Select the simplest coordination pattern that fits the work. Do not create multiple agents merely because they are available.

| Work condition | Use this pattern | Management action |
|---|---|---|
| One small, coherent task with little uncertainty | Single agent | Keep one accountable executor; review the completed output. |
| Known, independent subtasks | Planned parallel work | Define all work packages before dispatching; run only dependency-free tasks concurrently. |
| A task must follow an earlier result | Sequential chain | Set an explicit handoff artifact and gate each next task on acceptance of the prior result. |
| The required subtasks emerge during execution | Orchestrator–workers | Delegate discovery and execution in short waves; revise the task register after each wave. |
| High-stakes, subjective, or error-sensitive output | Producer–reviewer loop | Assign an independent reviewer with explicit criteria; require revision or escalation before integration. |
| Many related tasks (roughly 10+) | Workstreams and rolling-wave planning | Cluster by deliverable, domain, or dependency; assign a lead per workstream and plan detail only for the next executable wave. |

Use fixed, prescriptive workflows for well-defined, repeatable work. Use adaptive agents only when the path or task count cannot reasonably be predicted. Parallel sectioning is appropriate only when the pieces are independent; a manager must still reconcile them afterwards.[4]

## 1. Establish the Project Charter

Before assigning work, create a short charter. Ask the user only for information essential to a decision; otherwise record reasonable assumptions and expose them for review.

| Field | Required content |
|---|---|
| Objective | One measurable outcome stated in plain language. |
| Deliverables | The artifacts, decisions, or completed actions the user expects. |
| Acceptance criteria | The observable tests that make each deliverable acceptable. |
| Scope boundaries | What is included, explicitly excluded, and assumed. |
| Constraints | Deadline, budget/credit ceiling, tools, source requirements, format, compliance, and audience. |
| Risk and authority | Potential harm; actions requiring user confirmation; actions agents must never take autonomously. |
| Priority rule | How to decide trade-offs among value, urgency, risk, effort, and dependencies. |
| Communication cadence | When the manager will update the user and when agents must report blockers. |

State a **Definition of Done** for the project and, when necessary, for each work package. A strong definition includes content requirements, evidence or citations, format, validation method, and integration location. Keep a single ordered backlog as the authoritative queue; transparency and frequent inspection enable informed adaptation.[2]

## 2. Decompose Deliverables into Work Packages

Start with the final deliverable, then break it into mutually understandable components. Apply the following tests to each candidate work package:

1. **Outcome test:** It produces a tangible intermediate or final artifact, decision, or verified result.
2. **Boundary test:** Its inputs, scope, and exclusions distinguish it from adjacent work.
3. **Ownership test:** One agent is accountable for completing it, even if others contribute.
4. **Acceptance test:** Another agent can assess whether it is done without guessing intent.
5. **Dependency test:** Its predecessors, successors, shared resources, and required handoffs are named.
6. **Sizing test:** It is small enough to complete and review in a single execution wave. Split oversized or ambiguous items before starting them.

Capture **100% of known in-scope work**, including coordination, quality assurance, integration, and user-facing delivery. Do not mix deliverable hierarchy with schedule order; represent sequencing separately through dependencies.[1]

### Task Register

Maintain this table in the working notes, a project file, or a task-management system. Update it whenever scope, status, owner, or dependencies change.

| ID | Work package / output | Owner | Inputs | Depends on | Priority | State | Acceptance criteria | Evidence / handoff |
|---|---|---|---|---|---|---|---|---|
| T-01 | Example: source inventory | Research agent | Charter, source rules | — | High | Ready | Covers agreed subtopics; source quality checked | `sources.md` |
| T-02 | Example: analysis section | Analyst | `sources.md` | T-01 | High | Blocked | Addresses questions; calculations reproducible | `analysis.md` |
| T-03 | Example: final synthesis | Manager | T-01, T-02 | T-01, T-02 | High | Not started | Meets project Definition of Done | Final deliverable |

Use only these states: **Not started**, **Ready**, **In progress**, **Blocked**, **In review**, **Done**, **Cancelled**. Do not label a task Done while validation, integration, or a required approval remains outstanding.

## 3. Map Dependencies and Form Execution Waves

Draw or tabulate predecessor relationships before dispatching workers. A task is eligible to start only if every required input is available, accepted, and accessible. Prefer a directed acyclic dependency map; if a cycle appears, resolve the design ambiguity, redefine a handoff, or elevate the decision.

| Dependency type | Example | Coordination rule |
|---|---|---|
| Finish-to-start | Analysis needs the validated source inventory | Start successor after the predecessor passes its quality gate. |
| Shared-input | Several writers use one research brief | Finalize and version the shared brief before parallel dispatch. |
| Merge dependency | Several analyses feed one recommendation | Specify a common schema, terms, and citation format before work begins. |
| Resource conflict | Two agents edit the same file or perform one sensitive action | Assign a single editor/action owner; serialize changes or use separate branch files. |
| Decision dependency | A policy or design choice determines all downstream tasks | Surface options and obtain the required decision before spending on dependent work. |

Create a **wave** from all Ready tasks that are independent of one another. After a wave completes, validate its outputs, update the register, then construct the next wave. If new work emerges, add it explicitly and reassess scope and priority rather than silently expanding the plan.

## 4. Control Parallelism and Agent Load

Set a work-in-progress (WIP) limit: the maximum number of active work packages or assignments at a time. Start with a conservative limit based on the availability of agents, complexity of integration, rate limits, and the manager's ability to review results. Reserve capacity to resolve blockers and integrate outputs; do not fill every agent with unrelated work.

A WIP limit is a pull rule, not a productivity target: begin a task only when it is Ready and capacity exists. When capacity opens, pull the highest-priority Ready task. Kanban guidance emphasizes visualizing work, limiting WIP, making policies explicit, managing flow, and using feedback loops; it warns that excessive utilization and context switching can degrade flow.[3]

| Signal | Interpretation | Manager response |
|---|---|---|
| Too many In progress tasks | Fragmented attention or weak prioritization | Stop starting new work; finish, cancel, or rescope active tasks. |
| Repeated Blocked tasks | Upstream ambiguity, missing access, or a bottleneck | Assign an unblocker, clarify the requirement, or reorder the plan. |
| Completed work waiting for merge | Integration is the bottleneck | Pause new production; validate and merge the queue. |
| Many revisions from review | Acceptance criteria or assignment quality is weak | Improve the brief and add a preflight check before new dispatches. |
| A task is significantly larger than expected | The work package is not executable as framed | Split it, update dependencies, and estimate the remaining pieces. |

For more than roughly ten tasks, group the register into **workstreams** with a lead agent responsible for local sequencing and a manager responsible for cross-workstream dependencies, shared standards, and final integration. Limit lead responsibilities to a coherent deliverable area; avoid multiple agents acting as final decision-maker for the same issue.

## 5. Issue Complete, Non-Overlapping Agent Briefs

Give every worker a concise written brief. Refer to the task ID and authoritative shared materials. Ensure adjacent agents are not asked to produce the same output unless deliberate independent review or comparison is requested.

```markdown
Task: [ID — short title]
Project objective: [one sentence]
Your ownership boundary: [what to do, and what not to do]
Inputs and source locations: [links/files/context]
Expected output: [artifact, location, schema/format]
Acceptance criteria: [specific checks]
Dependencies and handoffs: [predecessors, consumers, shared interfaces]
Constraints: [deadline, tools, evidence, budget, style, policies]
Autonomy limits: [what must be escalated; prohibited external actions]
Status protocol: [when and how to signal progress/blocker/completion]
```

Require workers to return a completion note in this format:

```markdown
Status: Done | Blocked | Needs decision
Task: [ID]
Output: [file paths, links, or concise result]
Acceptance evidence: [checks performed and findings]
Assumptions / deviations: [only material items]
Dependencies affected: [IDs or none]
Recommended next action: [one clear action]
```

Do not use progress narratives as a substitute for artifacts, evidence, or an explicit blocker. A worker who cannot proceed should identify the missing input, impact, options, and recommended owner for resolution.

## 6. Monitor, Replan, and Escalate

Inspect the register at predictable checkpoints: after each execution wave, before a milestone, on receipt of a blocker, and before final delivery. Keep inspection lightweight and focused on decisions.

| Review question | Evidence to inspect | Action if unhealthy |
|---|---|---|
| Are we delivering the objective? | Accepted outputs versus charter criteria | Reprioritize, rescope with the user, or stop low-value work. |
| Is work flowing? | Counts by state, blocked age, review queue, unmet dependencies | Reduce WIP, remove a bottleneck, or resequence work. |
| Is quality holding? | Acceptance results, defect/revision patterns, source checks | Strengthen criteria, add an independent review, or redo defective outputs. |
| Are costs and time bounded? | Remaining work, tool usage, iteration count, deadline | Set stopping conditions, narrow scope, or request a user trade-off. |
| Is safety preserved? | Pending external actions and authority boundaries | Pause and request explicit confirmation before committing any consequential action. |

Use these escalation rules:

| Situation | Required response |
|---|---|
| Worker is blocked by a missing fact, decision, or permission | Record the blocker; seek the minimum needed clarification from the owner or user; work on independent tasks meanwhile. |
| Scope changes materially | Update charter, task register, dependencies, priorities, and WIP before assigning new work. |
| Task fails its quality gate | Return targeted feedback; allow a limited revision attempt; then reassign, split, or escalate rather than repeating an unproductive loop. |
| Sources conflict or results disagree | Preserve the conflict, evaluate source quality/methodology, and either reconcile with evidence or clearly present alternatives. |
| Deadline is at risk | Offer clear trade-offs: reduce scope, lower noncritical quality effort, add approved capacity, or move the deadline. Do not silently sacrifice agreed acceptance criteria. |
| Requested action can publish, purchase, submit, delete, transfer, or expose sensitive information | Prepare a draft or preview and obtain the required user confirmation before executing. |

## 7. Integrate and Verify

The manager owns synthesis. Do not concatenate worker outputs without reconciling terms, assumptions, duplicate research, conflicting claims, calculations, voice, and formatting.

1. Verify every required task is Done or formally deferred/cancelled with a visible reason.
2. Check each output against its acceptance criteria and validate citations, calculations, links, and files as appropriate.
3. Reconcile overlaps and contradictions using the strongest available evidence; preserve uncertainty rather than inventing consensus.
4. Assemble the final deliverable to the user's requested format and confirm it meets the project Definition of Done.
5. For consequential or complex work, use an independent reviewer to test completeness, correctness, and compliance against the charter.
6. Provide a concise final status identifying deliverables, material assumptions, deferred items, and recommended follow-up only when useful.

Use an evaluator–optimizer loop when quality criteria can be articulated and an independent review will measurably improve the result. Agent systems work best with environmental feedback, clear termination conditions, and tested safeguards against compounding error.[4]

## Coordination Policies

Apply these policies unless the user provides a stronger instruction:

- Keep a single accountable manager and a single source of truth for task status.
- Assign one task owner per deliverable; collaborators may help but do not dilute accountability.
- Prefer small, reviewable work packages over large, multi-purpose prompts.
- Parallelize independent production or independent reviews, never unresolved dependencies.
- Make interfaces explicit before running parallel work: common vocabulary, schemas, source standards, file locations, and merge owner.
- Treat status updates, assumptions, and newly discovered work as project data; record material changes immediately.
- Timebox investigation and revision loops; escalate when extra work requires a user trade-off.
- Protect user authority and sensitive data throughout the workflow.
- End each project with a brief retrospective: note one improvement to the task template, dependency map, WIP limit, or quality gate for the next comparable project.

## References

[1]: https://www.pmi.org/learning/library/applying-work-breakdown-structure-project-lifecycle-6979 "Project Management Institute — Applying the work breakdown structure to the project management lifecycle"
[2]: https://scrumguides.org/scrum-guide.html "Schwaber & Sutherland — The Scrum Guide (2020)"
[3]: https://kanban.university/kanban-guide/ "Kanban University — The Kanban Method"
[4]: https://www.anthropic.com/engineering/building-effective-agents "Anthropic — Building effective agents"
