# OpenManus Production Review

## Architecture

- Keep UI, API/adapter, worker/runtime, model endpoint, tools, persistence, validation, and artifact storage explicit.
- Avoid running long agent activations inside an HTTP request that the platform may terminate.
- Prevent direct client access to model keys, OpenManus processes, shell, MCP transports, or internal workspaces.
- Isolate agent state and filesystem state across concurrent tasks.

## Secrets and data

- Load secrets from server-side storage and inject only where required.
- Redact credentials, authorization headers, signed URLs, sensitive prompts, and environment variables from logs.
- Define retention for prompts, model exchanges, tool output, browser history, screenshots, files, and artifacts.
- Authorize every task, event, and artifact lookup by owner or role; an unguessable ID is not authorization.

## Tools and sandbox

- Default-deny tools, paths, commands, hosts, and external actions.
- Use a per-task workspace with canonical-path checks and size limits.
- Constrain shell, Python, browser, and file operations in a sandbox where practical.
- Restrict network egress and block cloud metadata or internal-service ranges unless explicitly required.
- Require confirmation for deletion, purchases, messages, publishing, account changes, and other consequential actions.
- Bound tool time, output, retries, and concurrency.

## Agent loop

- Set step, token, wall-time, tool-call, write, replan, fan-out, cost, and output limits.
- Detect repeated ineffective actions and stop with a useful terminal reason.
- Support cancellation during inference and tool execution when possible.
- Ensure every path reaches a durable waiting or terminal state and invokes cleanup.
- Do not expose hidden reasoning; publish concise progress, selected action, and observed result.

## Provider and model

- Confirm base URL, provider type, model name, authentication, TLS, and timeout from the worker host.
- Test plain inference, required tool calls, malformed arguments, token exhaustion, throttling, and provider downtime.
- Test local-model endpoints from the OpenManus network namespace, not only a developer workstation.
- Record model/profile versions so behavior changes are traceable.

## Queue and persistence

- Use idempotency keys for task creation when duplicates matter.
- Claim tasks atomically, use leases and heartbeats, and recover abandoned work.
- Reject stale goal, checkpoint, or lease versions.
- Retry only safe operations and track side effects to prevent duplicate external actions.
- Apply backpressure, maximum attempts, per-user quotas, and quarantine.
- Persist event sequence numbers so clients can resume interrupted streams.

## Observability

- Propagate a correlation ID through API, queue, worker, OpenManus events, tools, and provider calls.
- Record sanitized structured events, timings, step, tool, outcome, usage, and terminal category.
- Alert on stuck tasks, cleanup failures, sandbox-policy violations, provider errors, excessive cost, and queue age.
- Distinguish API health, worker availability, queue access, model reachability, and tool/sandbox readiness.

## Verification gates

Before release, demonstrate:

1. A normal task produces the expected validated result or artifact.
2. Invalid input is rejected before runtime execution.
3. Timed-out, canceled, approval-waiting, and provider-failed tasks reach correct durable states.
4. Two users cannot read each other's tasks or artifacts.
5. Malicious paths, commands, URLs, and tool arguments are denied.
6. Secrets do not appear in clients, responses, logs, history, or artifacts.
7. Worker termination does not leave a task permanently running.
8. Duplicate events and stale workers cannot double-commit work.
9. Browser, MCP, sandbox, workspace, and lease cleanup is verified.
10. Objective validators—not agent self-report—control durable success.
