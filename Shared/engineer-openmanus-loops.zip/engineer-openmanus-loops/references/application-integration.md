# OpenManus Application Integration

## Select the smallest viable topology

### Prototype

Run the web backend and OpenManus in one Python service. Create one agent per request, enforce a short timeout, and return the final result. Restrict this to one user and bounded tasks.

### Durable single-user app

Run the API and worker as separate processes. Store task state and artifacts durably. Submit work through a queue and stream progress with Server-Sent Events or WebSockets.

### Multi-user service

Use an authenticated API, durable task database, queue, isolated workers, per-task workspaces, centralized secret references, quotas, and an artifact store. Scale workers independently from the UI and API.

## Component contract

| Component | Owns | Must not own |
|---|---|---|
| UI | Prompt entry, status, task history, approvals, artifact download | API keys, raw shell access, OpenManus internals |
| API/adapter | Authentication, validation, task records, queueing, event delivery, cancellation | Agent reasoning loop |
| Worker | Agent creation, bounded runtime invocation, progress translation, cleanup | User-authentication UI |
| OpenManus | Activation-local memory, steps, model/tool loop, termination | Durable multi-user state by default |
| Model endpoint | Inference | Application authorization or tool policy |
| Tool sandbox | Bounded execution and artifacts | Unrestricted host access |

## Minimal task API

```text
POST   /api/tasks                  create task; return 202 + task_id
GET    /api/tasks/{task_id}        fetch sanitized status/result
GET    /api/tasks/{task_id}/events stream progress via SSE
POST   /api/tasks/{task_id}/cancel request cancellation
POST   /api/tasks/{task_id}/input  provide approval or requested input
GET    /api/tasks                  list authorized task history
```

Example task record:

```json
{
  "id": "task_123",
  "owner_id": "user_123",
  "status": "queued",
  "goal_version": 1,
  "created_at": "...",
  "started_at": null,
  "finished_at": null,
  "current_step": 0,
  "checkpoint_version": 0,
  "result": null,
  "artifacts": [],
  "error": null,
  "cancel_requested": false
}
```

Never let a client choose arbitrary provider URLs, commands, paths, identities, or tool permissions unless an administrator explicitly enables and validates those controls.

## Lifecycle

1. Authenticate and authorize the caller.
2. Validate prompt size, attachments, selected worker profile, and quota.
3. Create the task record and enqueue its ID.
4. Atomically grant an expiring lease to a worker.
5. Create an isolated workspace and OpenManus activation.
6. Translate safe runtime events into sequenced progress events.
7. Exit to `waiting_for_user` when approval or clarification is required.
8. Validate and persist the checkpoint, result, artifacts, receipts, or error category.
9. Clean up agent, MCP, browser, sandbox, temporary resources, and lease.
10. Retain or delete task data according to policy.

Use conditional state updates so two workers cannot commit the same task version. Cancellation must set a durable flag and signal the active worker; check it between steps and during cancellable tool calls.

## Python adapter boundary

Prefer a narrow adapter around runtime creation:

```python
async def execute_activation(request: ActivationRequest) -> ActivationResult:
    agent = await Manus.create()
    try:
        # Inject approved tools, workspace, budgets, context, and event hooks.
        raw_result = await agent.run(request.goal)
        return normalize_result(raw_result, request)
    finally:
        await agent.cleanup()
```

Confirm factory, run, cancellation, and cleanup signatures against the target revision. Pseudocode is not a substitute for inspection.

## Deployment questions

- Does the worker host support the required Python and native/browser dependencies?
- Can the worker outlive the public HTTP request timeout?
- Is task state durable across deployments and restarts?
- Can the worker reach the model endpoint, MCP servers, and approved websites?
- Are file and browser operations isolated per user and task?
- Where are artifacts stored, scanned, authorized, and expired?
- How are concurrency, tokens, cost, steps, tools, and output limited?
- Can clients reconnect to event streams from a stored sequence number?
