# Official OpenManus Project Map

Use this as orientation, then verify every item against the current target branch. The map reflects an official upstream snapshot reviewed on 2026-08-23.

## Entry points and modes

| Path | Observed upstream role |
|---|---|
| `main.py` | Creates `Manus`, accepts a prompt, calls `agent.run()`, and cleans up. |
| `run_mcp.py` | Runs the MCP-oriented agent entry point. |
| `run_flow.py` | Runs the experimental multi-agent flow. |
| `sandbox_main.py` | Runs with the configured sandbox path. |
| `run_mcp_server.py` | Exposes the project's MCP server path. |

The reviewed upstream README recommends Python 3.12 and `uv`, while also documenting a Conda installation. Verify current requirements before installing.

## Runtime structure

| Area | Observed upstream responsibility |
|---|---|
| `app/agent/base.py` | Agent state, memory, bounded step loop, stuck-state handling, and abstract `step()`. |
| `app/agent/react.py` | ReAct-style think/action abstraction. |
| `app/agent/toolcall.py` | LLM tool selection, execution, results, and termination behavior. |
| `app/agent/manus.py` | General-purpose Manus agent and local/MCP tool collection. |
| `app/agent/mcp.py` | MCP-focused agent behavior. |
| `app/agent/data_analysis.py` | Data-analysis specialization used by run-flow when enabled. |
| `app/flow/` | Multi-agent orchestration. |
| `app/llm.py` | Provider-facing LLM behavior and token accounting. |
| `app/config.py` | Project configuration parsing. |
| `app/schema.py` | Messages, memory, tool calls, and agent-state schemas. |

## Tool structure

`app/tool/base.py` defines the tool/result contract. `app/tool/tool_collection.py` registers tools and dispatches executions. Reviewed upstream code includes termination, human input, Python, file editing, planning, search/crawling, MCP, sandbox, and browser-related capabilities; exact availability changes between revisions.

`Manus` extends `ToolCallAgent`, which follows the ReAct and base-agent path. The base loop is step-limited and owns process-local state and memory. An application adapter should submit bounded work to the runtime and translate events rather than duplicating the loop in frontend code.

## Configuration orientation

Verify fields against the target `config/` examples and configuration parser:

- `[llm]`: model, base URL, API key, token limit, temperature, and provider-specific fields;
- `[llm.vision]`: optional vision-model configuration;
- `[browser]` and `[browser.proxy]`: browser connection and proxy settings where supported;
- `[search]`: engine, fallback, retry, language, and country options;
- `[sandbox]`: enablement, image, workspace, resource limits, timeout, and network access;
- `[mcp]`: MCP server reference;
- `[runflow]`: optional agent enablement;
- `config/mcp.example.json`: external MCP server definitions.

Never copy example configuration into a client-visible directory. Supply real credentials through server-side secret storage or deployment configuration.

## Browser behavior

The reviewed official README states that OpenManus starts Browser Use CLI as a default MCP server. It documents an opt-out environment variable and optional cloud/browser settings. Verify current behavior in the target `Manus` initialization path before relying on it.

## Primary sources

- `https://github.com/FoundationAgents/OpenManus`
- `https://github.com/FoundationAgents/OpenManus/blob/main/README.md`
- `https://github.com/FoundationAgents/OpenManus/tree/main/app`
- `https://github.com/FoundationAgents/OpenManus/tree/main/app/agent`
- `https://github.com/FoundationAgents/OpenManus/tree/main/app/tool`
- `https://github.com/FoundationAgents/OpenManus/blob/main/config/config.example.toml`
- `https://github.com/FoundationAgents/OpenManus/blob/main/config/mcp.example.json`
