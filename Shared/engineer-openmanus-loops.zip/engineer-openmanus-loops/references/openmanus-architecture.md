# OpenManus Durable Loop Architecture

## Contents

1. Component mapping
2. Nested execution model
3. Worker contracts
4. Durable state mapping
5. Checkpoint requirements
6. Tool and MCP gateway
7. n8n and PostgreSQL ownership
8. OpenManus adaptation targets
9. Implementation phases
10. Acceptance tests
11. Anti-patterns

## 1. Component mapping

Verify every symbol against the pinned target checkout.

| Component | Framework responsibility | Durable-loop interpretation |
|---|---|---|
| `BaseAgent.run()` | Finite step loop with a step cap | One bounded activation |
| `ReActAgent` | `think` then `act` behavior | Inner reasoning/action loop |
| `ToolCallAgent` | Structured tool selection and result handling | Tool-use layer |
| `Manus` | Concrete worker with configured tools | General worker profile |
| `PlanningFlow` | Plan creation, agent selection, step execution | Bounded supervisor activation |
| `ToolCollection` | Tool registration and dispatch | Base for a governed gateway |
| MCP clients/tools | External capability connections | Controlled integration boundary |
| `Memory` | In-process message history | Activation-local context only |
| `AgentState` | IDLE/RUNNING/FINISHED/ERROR | Local status only |
| sandbox classes | Selected code/tool isolation | Worker isolation boundary |
| interactive entry points | Prompt or flow launch | Development clients, not schedulers |

Expected lineage:

```text
BaseAgent -> ReActAgent -> ToolCallAgent -> Manus
```

Observed roles do not imply that durable scheduling, persistence, approvals, or recovery are native features.

## 2. Nested execution model

Use four bounded layers:

```text
availability loop
  -> supervisor activation
      -> agent activation
          -> think/action and tool calls
```

- **Availability loop:** waits for events, schedules, approvals, and recovery signals without continuously calling a model.
- **Supervisor activation:** uses `PlanningFlow` or an equivalent to choose a bounded unit of work.
- **Agent activation:** runs `BaseAgent.run()` under cumulative and per-activation budgets.
- **Tool cycle:** uses `ReActAgent`, `ToolCallAgent`, and governed tools to perform finite actions.

Each layer needs an owner, an explicit bound, a stop condition, and a persisted handoff if work can outlive the process.

## 3. Worker contracts

Example activation request:

```json
{
  "run_id": "run_123",
  "lease_id": "lease_7",
  "goal_version": 3,
  "checkpoint_version": 5,
  "goal": "Produce a validated research artifact",
  "acceptance_tests": [],
  "checkpoint": {},
  "remaining_budgets": {
    "steps": 12,
    "tool_calls": 20,
    "wall_seconds": 300,
    "cost_units": 100,
    "replans": 2
  },
  "allowed_agents": ["manus-research"],
  "allowed_tools": ["approved-search", "approved-fetch"],
  "pending_work": [],
  "approvals": []
}
```

Example activation response:

```json
{
  "status": "completed|waiting|approval_required|retryable|blocked|failed",
  "terminal_reason": "validated|step_complete|budget|wait|approval|error",
  "completed_actions": [],
  "evidence": [],
  "checkpoint": {},
  "remaining_work": [],
  "approval_request": null,
  "usage": {},
  "side_effect_receipts": []
}
```

Validate both schemas. Bind the response to `run_id`, `lease_id`, goal version, and checkpoint version before committing it.

## 4. Durable state mapping

| OpenManus-local signal | Durable interpretation |
|---|---|
| IDLE before dispatch | ready or waiting |
| RUNNING with current lease | leased/running |
| FINISHED and validators pass | succeeded or step_completed |
| FINISHED with pending work | checkpointed/requeued |
| Tool requires approval | approval_required |
| Recoverable ERROR | retry_scheduled |
| Non-recoverable ERROR | failed or quarantined |
| Worker disappears or lease expires | recovery_pending |

Local `FINISHED` never bypasses outcome validation.

## 5. Checkpoint requirements

Persist:

- run ID, trigger identity, goal version, and durable state version;
- plan version, completed steps, pending dependencies, join state, and replan count;
- evidence and artifacts with origin, capture time, freshness, and integrity hashes;
- remaining and cumulative budgets;
- minimal resumable memory summary and required messages;
- tool idempotency keys, side-effect receipts, and indeterminate outcomes;
- approval requests, action hashes, decisions, and expiry;
- failure class, attempt count, and next eligible retry time;
- code, model, configuration, policy, and tool versions.

Commit with optimistic concurrency and the active lease. Resume by reconstructing context from the current goal, latest checkpoint, authoritative sources, relevant memory, tool schemas, and policy.

## 6. Tool and MCP gateway

Wrap `ToolCollection` and MCP dispatch so every call:

1. verifies allowed tool, identity, target, and lease;
2. validates typed parameters;
3. classifies the consequence level;
4. requires preview or approval when policy demands it;
5. attaches an idempotency key where replay is possible;
6. records request, result, error class, timing, and receipt;
7. reconciles unknown external commit state before retry.

Never let MCP server availability substitute for tool authorization or side-effect tracking.

## 7. n8n and PostgreSQL ownership

Recommended flow:

```text
n8n trigger
  -> PostgreSQL event inbox and run ledger
  -> queue or expiring claim
  -> stateless OpenManus worker
  -> external validator
  -> checkpoint and transition
  -> requeue, wait, approve, retry, or complete
```

| Concern | Owner |
|---|---|
| Webhooks, schedules, approval callbacks, notifications | n8n |
| Event deduplication and correlation | PostgreSQL |
| Run identity, versions, states, attempts | PostgreSQL |
| Queue ordering and exclusive lease | queue or PostgreSQL claim table |
| Planning, reasoning, and tool selection | OpenManus |
| Tool policy and receipts | gateway plus PostgreSQL |
| Outcome validation | deterministic service, grader, or human |
| Retry timing and abandoned-run recovery | scheduler/recovery controller |

Useful tables include `event_inbox`, `runs`, `run_leases`, `plan_steps`, `checkpoints`, `evidence_items`, `artifacts`, `approvals`, `side_effects`, `run_events`, and `event_outbox`.

## 8. OpenManus adaptation targets

Confirm paths and method signatures before editing.

| Target area | Adaptation |
|---|---|
| schema module | Add or reference run context, activation result, checkpoint, budget, wait, and approval schemas. |
| base agent module | Accept persisted context, enforce budgets, support cancellation, and return structured terminal reasons. |
| planning flow module | Persist plan/step identities, cap replans, validate steps, and expose remaining work. |
| tool collection module | Route dispatch through policy, approval, idempotency, and receipt hooks. |
| Manus agent module | Support scoped worker profiles, allowed tools, injected context, and resumable initialization. |
| entry points | Retain interactive clients; add a stateless API or queue-worker activation endpoint. |
| external adapters | Add ledger, lease, checkpoint, recovery, scheduler, validator, and event adapters. |

Use dependency injection for ledgers, policy gateways, clocks, validators, and tool clients.

## 9. Implementation phases

1. Bound one activation with structured input/output, budgets, terminal reasons, and validation.
2. Add durable run state, goal versioning, checkpoints, and side-effect receipts.
3. Add queue leases, heartbeats, classified retries, backoff, and abandoned-run recovery.
4. Add tool policy, approvals, scoped identities, reconciliation, and quarantine.
5. Add event/schedule orchestration and bounded PlanningFlow delegation.
6. Prove reliability with fault injection, repeated trials, and operational release gates.

## 10. Acceptance tests

Demonstrate that:

- a killed worker resumes from the last accepted checkpoint on another worker;
- duplicate events converge on one logical run;
- stale goal versions and expired leases cannot commit;
- tool side effects do not duplicate after replay or timeout;
- all budgets stop execution at their declared limits;
- approval waits release the worker and consume no model turns;
- partial PlanningFlow failures preserve accepted evidence and remaining work;
- validators, not agent claims, determine success;
- no event can create an infinite model-calling loop.

## 11. Anti-patterns

Reject:

- a permanent `while true` wrapper around `Manus.run()`;
- in-process `Memory` as the durable checkpoint;
- `AgentState.FINISHED` as business success;
- n8n execution history as the only resume record;
- unrestricted tools or shared credentials across agents;
- write retries without idempotency and reconciliation;
- transcript-only persistence;
- unbounded PlanningFlow fan-out, depth, or replanning.
