---
name: engineer-openmanus-loops
description: Design, explain, implement, review, and troubleshoot applications and durable agent systems powered by FoundationAgents/OpenManus. Use for OpenManus architecture, Manus workers, PlanningFlow, ReAct and tool-calling loops, custom agents and tools, MCP, sandboxes, backend adapters and task APIs, web or Replit integration, hosted or local model configuration, deployment, observability, n8n or PostgreSQL control planes, resumable jobs, checkpoints, queues, leases, approvals, retries, recovery, and multi-agent supervision.
---

# Engineer OpenManus Loops

Build continuously available systems without running an infinite model loop. Use OpenManus for finite reasoning, planning, and tool execution; place durability and availability around it.

## Source of truth

Treat the user's repository, branch, configuration, and runtime logs as authoritative. OpenManus changes quickly. Inspect the target revision before naming files, classes, configuration fields, commands, dependencies, provider behavior, or browser/MCP defaults.

When no repository is supplied and current details matter, consult the official project first:

- `https://github.com/FoundationAgents/OpenManus`
- `https://openmanus.github.io/`

Use `references/official-project-map.md` only as orientation, then verify it against the target revision.

## Route the request

| Request | Action | Load |
|---|---|---|
| Explain OpenManus | Trace one request across app, runtime, model, and tools | `references/official-project-map.md` |
| Design or build an app | Define interfaces, lifecycle, deployment, and loop controls | `references/application-integration.md` and `references/openmanus-architecture.md` |
| Configure a provider or local model | Verify current config and test inference plus tool calling | `references/official-project-map.md` |
| Add agents, tools, MCP, or sandboxing | Inspect current extension points and enforce scoped execution | `references/official-project-map.md` and `references/production-review.md` |
| Debug a failure | Isolate installation, provider, tool, loop, network, sandbox, or state layer | Target repository and logs |
| Review production readiness | Audit boundaries, security, durability, cleanup, and verification | `references/production-review.md` |

## Application mental model

Keep these layers distinct:

1. **Client/UI** — accepts requests and displays sanitized state, events, approvals, artifacts, and results.
2. **Backend/adapter** — authenticates, validates, stores task records, queues work, streams progress, and translates runtime results.
3. **OpenManus runtime** — performs bounded memory, planning, reasoning, tool selection, execution, and termination.
4. **Model endpoint** — provides inference through a hosted API or reachable local service.
5. **Tool environment** — supplies browser, files, Python, shell, MCP, external APIs, and sandboxes.

An API key, model name, and base URL are configuration, not architectural layers. Keep OpenManus in a Python backend or worker, never browser JavaScript.

## Non-negotiable architecture

Separate three concerns:

- The **durable control plane** accepts events, owns run state, schedules work, leases jobs, waits for approvals, and recovers abandoned runs.
- The **OpenManus execution plane** performs one bounded activation and returns structured progress.
- The **validation plane** decides whether the activation satisfied objective acceptance criteria.

Never call `while true: await agent.run()` an always-on architecture. OpenManus worker processes may be ephemeral. The run identity, goal version, plan, evidence, budgets, approvals, side-effect receipts, and checkpoint must survive them.

## Workflow

### 1. Verify the target OpenManus version

Inspect the authorized target checkout before making code-specific claims. Record its repository, branch, and commit. Confirm class names, entry points, state enums, memory behavior, tool dispatch, MCP support, and sandbox implementation.

Use `references/openmanus-architecture.md` for the expected component roles. Treat the mapping as version-sensitive and report any differences found in the target.

For implementation work, inspect dependencies, configuration examples, agent/tool classes, entry points, and cleanup paths. Reuse upstream extension points and project conventions.

### 2. Define the run contract

Establish:

- trigger, correlation key, deduplication key, goal, and goal version;
- measurable acceptance tests and authoritative input rules;
- allowed agents, tools, identities, and data boundaries;
- step, tool-call, token, wall-time, cost, write, fan-out, depth, and replan budgets;
- checkpoint contents and resume behavior;
- approval and consequence boundaries;
- success, waiting, approval-required, retryable, blocked, failed, cancelled, expired, and recovery states.

Do not select infrastructure until these invariants are explicit.

### 3. Map the bounded OpenManus layers

Use the target version's equivalents of:

| Layer | OpenManus role |
|---|---|
| One worker activation | `BaseAgent.run()` |
| Think/action cycle | `ReActAgent` |
| Structured tool selection | `ToolCallAgent` |
| Concrete general worker | `Manus` |
| Bounded supervisor | `PlanningFlow` |
| Tool dispatch | `ToolCollection` and MCP clients |
| Activation-local context | `Memory` |
| Process-local status | `AgentState` |
| Execution isolation | sandbox implementation |

Keep event waiting, scheduling, durable state, leases, retry timing, approvals, and recovery external unless the target implementation explicitly adds and validates them.

### 4. Design the durable outer loop

Require these components or justified equivalents:

1. authenticated event and schedule ingress;
2. normalized event inbox with deduplication;
3. authoritative run ledger with optimistic versioning;
4. queue or claim table with exclusive expiring leases;
5. stateless OpenManus activation adapter;
6. policy-wrapped tool and MCP gateway;
7. checkpoint, evidence, artifact, and receipt stores;
8. deterministic, rubric-based, or human validators;
9. recovery scanner, bounded retries, and quarantine path;
10. traces, metrics, event history, and operator controls.

If using n8n and PostgreSQL, use n8n for triggers, schedules, callbacks, and notifications. Use PostgreSQL as the authoritative run ledger and checkpoint store. Do not rely on n8n execution history as the only resume mechanism.

### 5. Define the activation boundary

Send structured input containing at least:

`run_id`, `lease_id`, `goal_version`, `checkpoint_version`, `goal`, acceptance tests, checkpoint, remaining budgets, allowed agents, allowed tools, pending work, and approvals.

Require structured output containing at least:

`status`, `terminal_reason`, completed actions, evidence, checkpoint, remaining work, approval request, usage, and side-effect receipts.

Reject stale goal versions, expired leases, mismatched checkpoint versions, invalid schemas, and out-of-policy tool requests. An agent proposes a transition; the durable control plane commits it.

### 6. Govern tools and MCP

Wrap tool dispatch with typed validation, least-privilege identity, allowlists, consequence classification, preview, approval, idempotency keys, timeouts, retry classification, audit records, and external receipts.

Treat MCP as a capability transport, not an authorization, idempotency, or durability mechanism. Reconcile indeterminate external writes before retrying.

Give custom tools narrow names, precise schemas, bounded outputs, structured failures, and safe timeouts. Prevent arbitrary path access, command injection, secret exposure, unrestricted network egress, and unreviewed consequential actions.

### 7. Make checkpoint and recovery complete

Checkpoint the goal and plan versions, completed and pending step IDs, evidence provenance, artifact references, memory summary, cumulative and remaining budgets, approvals, receipts, failure classification, retry time, and runtime versions needed to resume.

Use compare-and-set writes bound to the active lease. A replacement worker resumes from the last committed checkpoint, not from an assumed in-process state or an entire transcript.

### 8. Validate the system

Test worker loss before and after checkpoint, duplicate events, expired leases, stale goal versions, partial PlanningFlow failure, rate limits, budget exhaustion, approval waits, goal changes, and indeterminate side effects.

Require repeated trials. Durable success comes from validators, not `AgentState.FINISHED`, plan completion text, or agent self-certification.

## Provider and local-model rule

Verify provider fields against the target configuration code and examples. Test plain inference and the exact tool/function-calling behavior required by the selected agent. An OpenAI-compatible endpoint is not proof of compatibility.

Treat a local model as a network endpoint. Use `localhost` only when it shares the OpenManus process's network namespace. In containers or split deployments, use a reachable service address. Keep credentials server-side and out of frontend code, committed configuration, logs, task history, and artifacts.

## Debugging workflow

Collect the exact command, working directory, OpenManus revision, Python/dependency versions, sanitized model configuration, traceback with preceding logs, and connectivity from the worker host to model, MCP, browser, and sandbox services.

Locate the failing boundary: installation, configuration, provider compatibility, model capability, tool schema, MCP transport, browser dependency, sandbox permission, networking, agent-loop behavior, budget exhaustion, cleanup, or adapter state. Fix the narrowest verified cause and rerun a minimal reproduction.

## Web and Replit rule

Keep runtime work behind an authenticated backend. Use server-side secret storage, durable task storage when history must survive restarts, and isolated workspaces for concurrent users. Do not expose raw environment variables, internal traces, config files, unrestricted shell/browser endpoints, or provider controls to the client.

## Multi-agent rule

Use one accountable supervisor with bounded fan-out. Give each OpenManus worker a narrow goal, scoped tools, explicit budget, evidence requirements, and a response schema. Define join, timeout, partial-failure, retry, replan, and escalation policies before delegation.

## Implementation output

For a design or build request, produce the applicable set of:

- architecture and nested-loop diagram;
- component ownership table;
- durable state-transition table;
- activation input/output schema;
- checkpoint schema and resume algorithm;
- OpenManus class and file adaptation map;
- tool/MCP policy and approval matrix;
- queue, lease, retry, idempotency, and reconciliation policy;
- evaluation suite, operational metrics, and launch gates;
- assumptions, version-specific observations, and unresolved decisions.

Lead with the recommended architecture and distinguish required controls from later optimizations.

## Reference

- `references/openmanus-architecture.md` — detailed OpenManus mapping, contracts, n8n/PostgreSQL pattern, implementation targets, tests, and anti-patterns.
- `references/official-project-map.md` — version-sensitive upstream entry points, runtime, tools, and configuration orientation.
- `references/application-integration.md` — UI/backend/worker boundaries, task API, lifecycle, and deployment topology.
- `references/production-review.md` — production security, isolation, durability, observability, cleanup, and release gates.
