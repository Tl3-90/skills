# DataCamp AI Engineering Learning Map

Use this map for source traceability and further study. Course availability and content can change; verify the current DataCamp catalog when exact current coverage matters.

## Foundations and prompting

- [Prompt Engineering with the OpenAI API](https://www.datacamp.com/courses/prompt-engineering-with-the-openai-api): message roles, precise prompts, structured outputs, few-shot and multi-step strategies, iterative refinement, business tasks, and chatbot context.
- [Introduction to LLMs in Python](https://www.datacamp.com/courses/introduction-to-llms-in-python): transformers, pre-trained models, Hugging Face workflows, fine-tuning, evaluation metrics, and safeguards.

## LLM application development

- [Developing LLM Applications with LangChain](https://www.datacamp.com/courses/developing-llm-applications-with-langchain): models, prompts, parsers, memory, chains, agents, custom tools, document loading, splitting, vector retrieval, and RAG chains.
- [LLMOps Concepts](https://www.datacamp.com/courses/llmops-concepts): ideation, data sourcing, model selection, prompts, chains and agents, RAG versus fine-tuning, testing, deployment, CI/CD, scaling, observability, cost, governance, and security.

## RAG and embeddings

- [Introduction to Embeddings with the OpenAI API](https://www.datacamp.com/courses/introduction-to-embeddings-with-the-openai-api): embedding creation, vector similarity, semantic search, recommendations, classification, Chroma, metadata, filtering, and cost estimation.
- [Retrieval Augmented Generation (RAG) with LangChain](https://www.datacamp.com/courses/retrieval-augmented-generation-rag-with-langchain): document loading, token and semantic splitting, dense and sparse retrieval, BM25, retrieval evaluation, faithfulness, Graph RAG, filtering, and graph-query validation.

## Agents and orchestration

- [Designing Agentic Systems with LangChain](https://www.datacamp.com/courses/designing-agentic-systems-with-langchain): ReAct agents, tools, state graphs, external APIs, memory, dynamic tool calls, and multi-turn workflows.
- [Multi-Agent Systems with LangGraph](https://www.datacamp.com/courses/multi-agent-systems-with-langgraph): graph-based agents, conditional tool calls, supervisor agents, and decentralized multi-agent patterns.
- [Building Agentic Workflows with LlamaIndex](https://www.datacamp.com/courses/building-agentic-workflows-with-llamaindex): tools, state, streaming events, multi-step events, concurrency, specialized research teams, and bounded reflection.
- [AI Agents with Hugging Face smolagents](https://www.datacamp.com/courses/ai-agents-with-hugging-face-smolagents): lightweight agent construction and tool-based execution.

## Models, multimodality, and serving

- [Multi-Modal Models with Hugging Face](https://www.datacamp.com/courses/multi-modal-models-with-hugging-face): computer vision, audio, CLIP-style classification, vision-language prompting, document question answering, diffusion editing, and video generation.
- [Create Generative AI Apps on Google Cloud](https://www.datacamp.com/courses/create-generative-ai-apps-on-google-cloud): foundation-model applications, prompt design, RAG architecture, Vertex AI prototyping, and an LLM/RAG chat application.
- [Deploy and Scale AI Models with Cloud Run](https://www.datacamp.com/courses/deploy-and-scale-ai-models-with-cloud-run): serverless inference, GPUs, lightweight language models, performance, cost efficiency, and service integration.

## Suggested sequence

1. Prompt Engineering with the OpenAI API
2. Introduction to LLMs in Python
3. Developing LLM Applications with LangChain
4. Introduction to Embeddings with the OpenAI API
5. Retrieval Augmented Generation (RAG) with LangChain
6. Designing Agentic Systems with LangChain
7. Multi-Agent Systems with LangGraph or Building Agentic Workflows with LlamaIndex
8. LLMOps Concepts
9. Select multimodal or cloud deployment courses according to the target system

