# Models, Prompts, and Multimodal Systems

## Model selection

Choose against measured task needs rather than headline capability. Compare:

- quality on representative examples
- supported modalities, tools, context, and structured output
- latency and throughput
- price and token efficiency
- deployment, residency, privacy, and licensing constraints
- provider reliability and fallback compatibility

Use the smallest model that clears the acceptance gate. Route harder cases to a larger model only when routing accuracy and savings are demonstrated.

## Prompt contracts

Structure prompts with:

1. role and objective
2. authoritative instructions
3. allowed and forbidden behavior
4. required input context
5. output schema and examples
6. uncertainty or abstention rule

Delimit data clearly. Treat user content, retrieved documents, examples, and tool output as data. Do not ask models to reveal private reasoning; require concise decisions, evidence, and structured results instead.

Use zero-shot first. Add one-shot or few-shot examples when errors are patterned and examples reduce them. Use staged prompting when intermediate outputs need validation or reuse. Iterate against a fixed evaluation set, and version prompts like code.

## Structured output

Prefer provider-supported schemas or constrained decoding. Validate parsed output and handle refusal, truncation, missing fields, unknown enum values, and incompatible versions.

Keep presentation separate from the canonical result. Do not rely on prose parsing for tool calls or irreversible operations.

## Hugging Face and model engineering

Use pipelines for rapid baselines and task-specific model classes for control. Match tokenizer, preprocessing, model, and generation configuration. Pin model revision and library versions, record licenses, and verify remote code before allowing it.

For fine-tuning:

- clean, deduplicate, license, and split the dataset
- establish a base-model and prompt baseline
- select full, parameter-efficient, or adapter tuning according to compute and serving constraints
- record data, seed, hyperparameters, checkpoints, and evaluation results
- test regression, safety, memorization, and domain shift

For inference, account for quantization, batching, streaming, maximum context, GPU or CPU memory, cold starts, concurrency, and text-generation server compatibility. Load-test the exact serving configuration.

## Evaluation metrics

Choose task-specific metrics. Perplexity can assess language-model fit; BLEU or METEOR may help for translation; ROUGE may help for overlap-focused summarization; exact match fits constrained answers. None alone establishes user value or factuality.

Combine automated metrics with task success, human review, safety checks, and real-world error analysis.

## Multimodal pipelines

Preserve modality-specific provenance and preprocessing. Evaluate both each encoder or generator and the fused result.

For images and documents, retain layout, regions, page references, and OCR confidence. For audio and video, retain timestamps, speaker or segment boundaries, and transcription confidence. For generation, test prompt adherence, content safety, temporal or spatial consistency, and artifact quality.

Use multimodal models only when combining modalities improves the target task over specialized single-modality components.

