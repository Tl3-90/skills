# Agents and Workflows

## Agent contract

Define an agent by its objective, allowed tools, state, stopping conditions, budget, and success test. Do not define it only by a persona.

Represent execution as observable state transitions. Prefer an explicit graph when branching, retries, approvals, or parallel work matter.

## Tool design

Make tools narrow, typed, and independently testable. Each tool must have:

- a clear description and use boundary
- validated input and output schemas
- least-privilege credentials
- explicit timeout and error behavior
- idempotency or deduplication for side effects
- audit events without secrets

Separate read tools from mutation tools. Require confirmation or policy approval before material, irreversible, financial, public, or privileged actions unless the user has explicitly authorized the exact action.

Do not let tool output redefine system policy. Validate paths, URLs, queries, and identifiers outside the model.

## State and memory

Distinguish:

- working state: data for the current execution
- conversation memory: prior turns needed for continuity
- episodic memory: selected past outcomes
- semantic memory: durable facts or knowledge

Store only what improves future performance. Define provenance, permissions, expiry, correction, and deletion. Summarize or retrieve memory rather than replaying unbounded histories.

## Single-agent workflow

Use a bounded loop:

1. inspect state
2. select an allowed action
3. validate the action
4. execute the tool or model step
5. record the observation
6. test completion or stop conditions

Set maximum steps, tokens, time, cost, retries, and repeated-action detection. Fail safely when budgets expire.

## Multi-agent patterns

Use a supervisor pattern when one coordinator should assign work, enforce policy, and combine results. Use a decentralized or swarm pattern only when peers can transfer control safely through explicit handoff contracts.

For specialized teams:

- give each role the minimum context and tools
- define input, output, completion, and handoff schemas
- identify the source of truth for shared state
- make concurrency safe and collect partial failures
- prevent cyclic delegation
- use independent validation for high-impact results

Keep research, writing, review, and execution roles separate when their evidence and permissions differ.

## Reflection and validation

Use critique or self-reflection as a bounded revision step, not an endless loop. Provide an explicit rubric and stop after the criteria are met or the revision budget is exhausted.

Prefer independent validators for factuality, policy, schemas, retrieval support, and tool safety. A validator must be able to reject, request repair, or escalate; it should not silently rewrite high-impact results.

## Tracing and evaluation

Trace model calls, prompt versions, state transitions, tool selections, tool arguments, outputs, errors, latency, tokens, and cost. Redact secrets and sensitive payloads.

Measure:

- end-to-end task success
- correct tool and argument selection
- invalid or unnecessary actions
- completion steps and repeated loops
- handoff and aggregation quality
- side-effect safety
- latency and cost

Compare every multi-agent design with a fixed workflow and a single-agent baseline.

