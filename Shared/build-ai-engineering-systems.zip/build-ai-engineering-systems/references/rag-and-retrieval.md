# RAG and Retrieval

## Pipeline

Design ingestion and query paths separately.

Ingestion:

1. acquire and authorize sources
2. parse while retaining structure
3. normalize and deduplicate
4. chunk according to document semantics
5. attach provenance, access, time, and domain metadata
6. embed and index
7. version the source, parser, chunker, embedding model, and index

Query:

1. classify or rewrite the request when useful
2. apply identity and metadata filters before retrieval
3. retrieve candidates
4. combine sparse and dense results when either alone misses evidence
5. rerank when candidate order materially affects quality
6. construct a bounded context with source identifiers
7. generate an answer constrained to evidence
8. return citations or abstain when support is insufficient

## Chunking

Choose boundaries from the source form: headings and paragraphs for prose, functions and classes for code, rows or logical groups for tables, and layout-aware blocks for documents.

Avoid selecting chunk size by convention alone. Test:

- answer-bearing context retained within one or a few chunks
- unrelated content not merged excessively
- retrieval precision after overlap
- token and indexing cost

Use recursive, token-aware, semantic, or code-aware splitting when fixed character splitting damages meaning.

## Embeddings and stores

Keep document and query embeddings compatible. Store raw source identifiers, chunk position, timestamps, authorization metadata, and embedding version with each vector.

Use vector storage for semantic similarity, sparse retrieval such as BM25 for exact terms, and hybrid retrieval when the corpus contains both conceptual language and identifiers. Use metadata filters for tenant, document type, date, jurisdiction, product, or other hard constraints.

Treat vector databases as indexes, not systems of record.

## Advanced retrieval

Add only after baseline measurement:

- multi-query or query decomposition for ambiguous or compound requests
- contextual compression to remove irrelevant passages
- self-query retrieval for structured filters
- reranking for higher precision
- parent-child retrieval for local match plus broader context
- Graph RAG for relationship-heavy questions that vector similarity misses

Use Graph RAG when entities and multi-hop relationships are central. Validate generated graph queries and constrain allowed labels, relations, and operations.

## Evaluation

Build cases with known relevant documents and supported answers. Measure retrieval independently from generation.

Retrieval metrics may include:

- recall at k
- precision at k or context precision
- mean reciprocal rank
- filter correctness
- evidence coverage

Generation metrics may include:

- answer correctness
- faithfulness to retrieved context
- citation correctness and completeness
- refusal or abstention quality

Inspect failures by stage: source missing, parse loss, poor chunk, embedding miss, filter error, ranking error, context construction, or generation error. Fix the earliest failing stage.

## Security

Enforce source permissions at retrieval time. Treat retrieved content as untrusted data. Detect or neutralize instructions found inside documents. Protect against poisoned sources, cross-tenant retrieval, sensitive metadata leakage, and malicious file parsing.

