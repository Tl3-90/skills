# Evaluation and LLMOps

## Lifecycle

Manage the system through ideation, development, release, operation, and retirement. Track application code together with model, prompt, tool, data, index, schema, and policy versions.

During ideation, define the user value, failure costs, data rights, build-versus-buy decision, and base-model constraints. During development, establish baselines before optimization. During operation, continuously compare live behavior with release gates and known risks.

## Evaluation set

Create cases from real workflows where authorized, synthetic boundary cases, adversarial inputs, prior incidents, and rare but costly failures. Label expected outcome, acceptable variants, evidence, severity, and evaluator method.

Maintain:

- development set for iteration
- holdout set for release decisions
- regression set from discovered failures
- safety and abuse set

Prevent evaluation contamination. Do not optimize repeatedly against the holdout.

## Evaluators

Use the least subjective reliable evaluator:

1. schema, unit, and invariant checks
2. reference comparisons and task-specific metrics
3. retrieval and tool traces
4. rubric-based model graders with calibration
5. human review for ambiguous or high-impact outcomes

For model graders, hide irrelevant metadata, randomize order for comparisons, use explicit rubrics, and compare with human labels. Do not use one model grader as the sole gate for critical safety.

## Release gates

Define thresholds for:

- task and component quality
- critical failure count
- safety and authorization behavior
- p50 and p95 latency
- error and timeout rate
- average and worst-case cost
- load and concurrency behavior

Block releases on critical regressions even when aggregate scores improve.

## Deployment

Serve the application behind a versioned interface. Validate requests, authenticate clients, authorize resources, cap payload and context size, and return stable error shapes.

Use CI/CD to run deterministic tests, offline evaluations, security checks, and compatibility checks. Deploy through staged traffic, shadowing, canaries, or feature flags when risk justifies it. Keep a tested rollback path for application, prompt, model, and index changes.

## Observability

Monitor:

- traffic, latency, throughput, errors, and saturation
- model and provider usage, tokens, and cost
- structured-output and refusal rates
- retrieval result count, score distribution, source coverage, and staleness
- tool selection, failures, repeated calls, and side effects
- user feedback and sampled task quality
- drift in inputs, outputs, and outcome metrics

Trace enough to reproduce failures while minimizing stored sensitive data. Define alerts with ownership and response procedures.

## Security and governance

Threat-model user input, retrieved content, models, tools, memory, logs, and generated output. Test:

- direct and indirect prompt injection
- unauthorized tool calls and excessive agency
- data exfiltration and cross-tenant access
- poisoned sources, indexes, or training data
- unsafe generated code, queries, files, and URLs
- secret and personal-data leakage
- denial of service and denial of wallet
- model or dependency supply-chain risk

Use least privilege, allowlists, sandboxing, human approval, output encoding, data minimization, retention limits, and audit logging according to risk.

## Cost and reliability

Estimate cost by traffic, input and output tokens, retrieval, tool calls, storage, inference hardware, and retry behavior. Control it with bounded context, prompt compression, caching where privacy permits, batching, model routing, step budgets, and asynchronous work.

Define timeouts, retries with backoff, circuit breakers, provider fallbacks, queues, and graceful degradation. Test the fallback itself; a configured fallback is not evidence of resilience.

