# Architecture Selection

## Decision table

| Pattern | Choose when | Avoid when | Primary evidence |
| --- | --- | --- | --- |
| Deterministic application | Rules and outputs can be specified exactly | Language understanding or generation is essential | Unit and integration tests |
| Prompt-only model call | One transformation or classification fits in the model context | The task needs private/current knowledge or dynamic actions | Task accuracy and schema validity |
| Chain or fixed workflow | Steps and order are predictable | The next action genuinely depends on runtime reasoning | Per-step and end-to-end tests |
| RAG | Responses depend on private, current, or attributable sources | The needed behavior is not knowledge-related | Retrieval and grounded-answer metrics |
| Fine-tuned model | Repeated behavior, format, style, or domain capability cannot be reached efficiently with prompting | Facts change often or the dataset is too small/poor | Holdout gain versus the base model |
| Single agent | The system must choose among tools or steps dynamically | A deterministic router can express the policy | Task success, tool accuracy, step count |
| Multi-agent system | Roles need isolated context/tools, independent review, or useful concurrency | One agent can reliably complete the task | Improvement over a single-agent baseline |
| Multimodal pipeline | The task requires text plus image, audio, video, or document layout | One modality contains all required evidence | Per-modality and fused-task performance |

## Selection sequence

1. Build or specify a deterministic baseline.
2. Add one model call if natural-language capability is required.
3. Add a fixed chain when decomposition improves reliability.
4. Add RAG when external knowledge is required.
5. Add tool choice and agent control only for dynamic execution.
6. Add agent specialization only after measuring the single-agent baseline.
7. Consider fine-tuning after prompt, data, retrieval, and evaluation quality are stable.

## RAG versus fine-tuning

Use RAG to supply facts. Use fine-tuning to change learned behavior. Combine them only when the system needs both current knowledge and specialized behavior.

Before fine-tuning, require:

- a stable task definition and baseline
- enough licensed, clean, representative examples
- a holdout set untouched by training
- a measurable improvement target
- an update and rollback strategy

## Chain versus agent

Use a chain when the workflow can be represented as explicit branches, loops, and checks. Use an agent when the action space is open enough that enumerating the path is impractical.

Convert recurring successful agent paths into deterministic workflow sections. Preserve agent reasoning only where runtime choice remains valuable.

## Multi-agent justification

Require at least one concrete benefit:

- distinct tool or permission boundaries
- contexts too large or conflicting for one agent
- independent generation and validation
- parallelizable tasks with aggregation
- domain roles with different policies

Measure against one capable agent. Include orchestration cost, duplicated context, coordination failures, and added latency in the comparison.

## Architecture decision record

Record:

- problem and constraints
- chosen pattern
- rejected alternatives
- component contracts
- evaluation gates
- operational and security risks
- assumptions that would trigger redesign

