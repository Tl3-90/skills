---
name: build-ai-engineering-systems
description: Design, implement, evaluate, review, and operate AI engineering systems built with large language models. Use for LLM application architecture, prompt engineering, chains, retrieval-augmented generation (RAG), embeddings, semantic search, vector or graph retrieval, tool-using agents, multi-agent workflows, memory and state, Hugging Face models, fine-tuning decisions, multimodal systems, model serving, LLM evaluation, observability, security, cost control, and LLMOps. Also use to turn an AI product idea into a technical plan, executable prototype, test strategy, or production-readiness review.
---

# Build AI Engineering Systems

## Objective

Turn an AI use case into the smallest reliable system that satisfies its quality, latency, cost, privacy, and operational constraints. Produce decisions and working artifacts rather than framework-driven demos.

## Core rules

- Start from the user task, data, failure costs, and evaluation criteria; do not start from a framework.
- Prefer deterministic code for rules, calculations, permissions, routing, and irreversible actions.
- Add retrieval when answers require private, current, or source-grounded knowledge.
- Add an agent only when the application must choose actions or tools dynamically.
- Add multiple agents only when specialization, isolation, or parallel work provides measurable value.
- Treat prompts, retrieval, models, tools, orchestration, and serving as independently testable components.
- Keep framework-specific code behind interfaces so models, stores, and orchestrators can be replaced.
- Record model, prompt, data, index, tool, and evaluation versions together.
- Never claim production readiness without task-specific evaluation, failure handling, observability, and security review.

## Reference routing

Read only the references needed for the task:

- Read [architecture-selection.md](references/architecture-selection.md) to choose among prompt-only, chains, RAG, fine-tuning, agents, multi-agent systems, and multimodal designs.
- Read [rag-and-retrieval.md](references/rag-and-retrieval.md) for ingestion, chunking, embeddings, vector databases, hybrid retrieval, reranking, Graph RAG, and retrieval evaluation.
- Read [agents-and-workflows.md](references/agents-and-workflows.md) for tools, memory, state graphs, delegation, supervisor or swarm patterns, tracing, and safe execution.
- Read [models-prompts-and-multimodal.md](references/models-prompts-and-multimodal.md) for prompt contracts, model selection, Hugging Face, fine-tuning, inference, and multimodal pipelines.
- Read [evaluation-and-llmops.md](references/evaluation-and-llmops.md) for test sets, metrics, deployment, monitoring, CI/CD, security, governance, and cost controls.
- Read [datacamp-learning-map.md](references/datacamp-learning-map.md) only when the user asks for provenance, DataCamp courses, or a learning sequence.

## Workflow

### 1. Frame the system

Capture or infer, and label assumptions for, the following:

- user and business outcome
- supported inputs, expected outputs, and output schema
- required knowledge sources and update frequency
- allowed tools and side effects
- latency, throughput, availability, and budget targets
- sensitive-data, access-control, compliance, and retention constraints
- acceptable and unacceptable failures
- evidence that will count as success

Ask one focused question only when a missing answer would materially change the architecture. Otherwise proceed with explicit assumptions.

### 2. Choose the minimum architecture

Use the decision criteria in `architecture-selection.md`. State why each major component is necessary. Reject unnecessary agent loops, vector databases, fine-tuning, or multi-agent layers.

Define:

- deterministic application layer
- model interface and structured output contract
- retrieval layer, if any
- tool layer and authorization boundary, if any
- state and memory model, if any
- evaluation and telemetry layer
- serving and persistence boundary

### 3. Design contracts before orchestration

Specify typed schemas for model outputs, retrieved documents, tool inputs and outputs, workflow state, errors, and trace events. Validate every external boundary. Make retries bounded and idempotent where side effects are possible.

Separate instructions from untrusted content. Do not place retrieved text, user uploads, or tool output in a privileged instruction channel.

### 4. Build a vertical slice

Implement one end-to-end path using representative data before expanding features. Default to Python when the user has no stack preference, but preserve the existing project stack when one exists.

For each slice:

1. Create the deterministic baseline.
2. Add the model call with a strict output schema.
3. Add retrieval or tools only when the baseline demonstrates the need.
4. Capture traces for prompt, retrieval, tool, latency, token, cost, and error events.
5. Add tests alongside the component being introduced.

Never expose secrets in source, logs, prompts, traces, or generated artifacts.

### 5. Evaluate from components to system

Create a versioned evaluation set from representative, edge, adversarial, and known-failure cases. Keep development and holdout cases separate.

Evaluate:

- deterministic correctness and schema validity
- retrieval relevance, coverage, and grounding
- answer correctness, faithfulness, safety, and usefulness
- tool selection, argument accuracy, and side-effect safety
- task completion and workflow efficiency
- latency, reliability, and cost

Use deterministic checks where possible, model-based grading where judgment is required, and human review for high-impact or ambiguous cases. Report confidence and known coverage gaps.

### 6. Harden and operate

Add timeouts, bounded retries, circuit breakers, rate limits, caching where safe, fallbacks, and graceful degradation. Define authorization for every data source and tool. Test prompt injection, poisoned retrieval, unsafe tool arguments, data leakage, denial-of-wallet patterns, and output handling.

Version and release prompts, models, indexes, schemas, and workflows through CI/CD. Monitor quality proxies together with latency, cost, traffic, errors, retrieval behavior, tool behavior, and user feedback. Define rollback conditions before launch.

### 7. Deliver the result

Match the user's requested artifact. When the format is unspecified, provide:

1. a concise architecture decision and assumptions
2. component and data-flow description
3. implementation or scaffold
4. evaluation plan with acceptance thresholds
5. production-readiness risks and next actions

Keep tutorials secondary to the working design. Include DataCamp links only when the user requests learning resources or source traceability.
